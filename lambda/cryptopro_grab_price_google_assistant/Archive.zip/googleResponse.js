module.exports = {
	getPriceUsd: function(callback) {
		console.log("getPriceUsd")
	},

	getPriceBtc: function(callback) {
		console.log("getPriceBtc);
	}
}
	
